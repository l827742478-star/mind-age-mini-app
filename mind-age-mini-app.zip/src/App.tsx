import { useEffect, useMemo, useState } from 'react'

type Screen = 'home' | 'quiz' | 'result'

type Question = {
  prompt: string
  scene: string
  options: string[]
}

const questions: Question[] = [
  {
    scene: '周一早上，闹钟响了三遍',
    prompt: '你会怎么做？',
    options: ['立刻起床，今天要掌控节奏', '再躺五分钟，但真的只五分钟', '先看一眼手机再说', '关掉闹钟，梦里继续上班'],
  },
  {
    scene: '朋友临时说：“今晚出来吗？”',
    prompt: '你的第一反应是？',
    options: ['好呀，生活需要一点即兴', '看心情，先问都有谁', '我需要提前安排，临时不太行', '太好了！马上换衣服出门'],
  },
  {
    scene: '网购的东西今天送到',
    prompt: '你会选择？',
    options: ['当场拆，快乐不能隔夜', '拍照留念，再慢慢拆', '先放门口，忙完再说', '拆完纸箱还要折好收起来'],
  },
  {
    scene: '计划好的周末突然下雨',
    prompt: '你会怎么安排？',
    options: ['改成室内活动，一样可以玩', '窝在家里看一整天剧', '把家务和待办清掉', '撑伞出门，雨天也有风景'],
  },
  {
    scene: '看到一条很有争议的评论',
    prompt: '你通常会？',
    options: ['先理解对方为什么这么想', '忍不住回两句', '直接划走，不让情绪占内存', '看完评论区才知道谁有理'],
  },
  {
    scene: '月底只剩一点预算',
    prompt: '你最像哪一种？',
    options: ['做个小表格，重新安排支出', '先把想吃的吃了再想办法', '不慌，平时有留备用金', '打开购物车，认真删掉一半'],
  },
  {
    scene: '临睡前突然想起一件小尴尬',
    prompt: '你会？',
    options: ['告诉自己：谁还没有黑历史', '越想越清醒，开始复盘', '明天醒来就忘了', '把它改写成下次的笑话'],
  },
  {
    scene: '一个人吃饭的时候',
    prompt: '你最舒服的状态是？',
    options: ['慢慢吃，顺便观察路人', '戴上耳机，沉浸在自己的世界', '边吃边处理工作消息', '刷短视频，时间过得特别快'],
  },
  {
    scene: '朋友找你倾诉烦恼',
    prompt: '你会先？',
    options: ['认真听完，再问对方需要什么', '马上给出解决方案', '陪着吐槽，先把情绪放出来', '讲一个自己的类似经历'],
  },
  {
    scene: '突然拥有一整天空闲时间',
    prompt: '你会怎么用？',
    options: ['去做一件拖了很久的事', '睡到自然醒再决定', '约一个很久没见的人', '安排一条说走就走的小路线'],
  },
  {
    scene: '看到小时候喜欢的东西',
    prompt: '你更接近哪种心情？',
    options: ['好怀念，想起很多细节', '现在看依然觉得好玩', '会买一个，送给现在的自己', '笑着看一会儿，然后继续生活'],
  },
  {
    scene: '做选择时，你更相信？',
    prompt: '哪一句话最像你？',
    options: ['先听听自己的感觉', '把利弊列清楚再决定', '试试看，答案会在路上', '选那个让未来更轻松的'],
  },
]

const resultCopy = [
  { max: 22, type: '好奇小行星', line: '你的心里还住着一个会发光的小朋友。', detail: '对新鲜事有雷达，快乐来得快，也愿意把小事过得有趣。' },
  { max: 29, type: '轻盈探险家', line: '你把成熟和好玩调成了刚刚好的比例。', detail: '有自己的节奏，也保留着说走就走的勇气，生活很难把你困住。' },
  { max: 36, type: '稳定发光体', line: '你知道什么时候认真，也知道什么时候松弛。', detail: '情绪有出口，选择有分寸，柔软和坚定可以同时存在。' },
  { max: 45, type: '温柔掌舵人', line: '你看过生活的复杂，但没有丢掉自己的天真。', detail: '比起热闹，你更在意真实；比起证明，你更愿意把日子过稳。' },
]

const lastResultKey = 'mind-age-last-result-v1'

function getSavedAge() {
  try {
    const value = Number(localStorage.getItem(lastResultKey))
    return Number.isFinite(value) && value > 0 ? value : null
  } catch {
    return null
  }
}

function App() {
  const [screen, setScreen] = useState<Screen>('home')
  const [current, setCurrent] = useState(0)
  const [answers, setAnswers] = useState<number[]>([])
  const [savedAge, setSavedAge] = useState<number | null>(null)
  const [toast, setToast] = useState('')

  useEffect(() => setSavedAge(getSavedAge()), [])

  const score = useMemo(() => answers.reduce((total, answer) => total + answer, 0), [answers])
  const age = useMemo(() => Math.round(16 + (score / (questions.length * 4)) * 29), [score])
  const result = resultCopy.find((item) => age <= item.max) ?? resultCopy[resultCopy.length - 1]
  const progress = ((current + (answers[current] ? 1 : 0)) / questions.length) * 100

  const startTest = () => {
    setAnswers([])
    setCurrent(0)
    setToast('')
    setScreen('quiz')
  }

  const chooseAnswer = (index: number) => {
    setAnswers((previous) => {
      const next = [...previous]
      next[current] = index + 1
      return next
    })
  }

  const nextQuestion = () => {
    if (!answers[current]) return
    if (current === questions.length - 1) {
      try {
        localStorage.setItem(lastResultKey, String(age))
      } catch {
        // Results still work if storage is unavailable.
      }
      setSavedAge(age)
      setScreen('result')
      return
    }
    setCurrent((value) => value + 1)
  }

  const previousQuestion = () => setCurrent((value) => Math.max(0, value - 1))

  const shareResult = async () => {
    const shareText = `我测出的心理年龄是 ${age} 岁，属于「${result.type}」！你也来测测？`
    try {
      if (navigator.share) {
        await navigator.share({ title: '我的心理年龄', text: shareText })
        setToast('已打开分享面板')
      } else if (navigator.clipboard) {
        await navigator.clipboard.writeText(shareText)
        setToast('结果文案已复制，去分享给朋友吧')
      } else {
        setToast('把这张结果卡截图分享给朋友吧')
      }
    } catch {
      setToast('把这张结果卡截图分享给朋友吧')
    }
    window.setTimeout(() => setToast(''), 2800)
  }

  return (
    <main className="app-shell">
      <div className="noise" aria-hidden="true" />
      {screen === 'home' && (
        <HomeScreen savedAge={savedAge} onStart={startTest} onShowSaved={() => savedAge && setScreen('result')} />
      )}
      {screen === 'quiz' && (
        <QuizScreen
          question={questions[current]}
          current={current}
          total={questions.length}
          answer={answers[current]}
          progress={progress}
          onChoose={chooseAnswer}
          onNext={nextQuestion}
          onBack={previousQuestion}
          onExit={() => setScreen('home')}
        />
      )}
      {screen === 'result' && (
        <ResultScreen
          age={age}
          result={result}
          toast={toast}
          onShare={shareResult}
          onAgain={startTest}
          onHome={() => setScreen('home')}
        />
      )}
    </main>
  )
}

function Brand() {
  return (
    <div className="brand" aria-label="心龄测试">
      <span className="brand-mark">✦</span>
      <span>心龄测试</span>
    </div>
  )
}

function HomeScreen({ savedAge, onStart, onShowSaved }: { savedAge: number | null; onStart: () => void; onShowSaved: () => void }) {
  return (
    <section className="screen home-screen">
      <header className="topbar">
        <Brand />
        <span className="tiny-label">MINI TEST · 01</span>
      </header>
      <div className="home-copy">
        <div className="eyebrow"><span /> 一个关于你的轻测试</div>
        <h1>你的心，<br /><em>其实住着几岁？</em></h1>
        <p className="lead">从日常选择里，找到那个藏在你身体里的真实年龄。凭第一感觉回答，结果会更像你。</p>
      </div>
      <div className="hero-orbit" aria-label="心龄星球插画">
        <div className="orbit orbit-one" />
        <div className="orbit orbit-two" />
        <div className="orbit-dot dot-one" />
        <div className="orbit-dot dot-two" />
        <div className="planet"><span>心</span></div>
        <div className="orbit-caption caption-one">curious<br />& kind</div>
        <div className="orbit-caption caption-two">since<br />today</div>
      </div>
      <div className="home-card">
        <div className="card-meta"><span>心龄档案 · 今日</span><span>约 3 分钟</span></div>
        <div className="card-rule" />
        <div className="card-stats"><span><strong>12</strong>道生活小题</span><span><strong>4</strong>种心龄类型</span><span><strong>0</strong>条数据上传</span></div>
      </div>
      <button className="primary-button" onClick={onStart}>开始测我的心龄 <span>→</span></button>
      {savedAge && <button className="saved-result" onClick={onShowSaved}>上次结果：心龄 {savedAge} 岁 <span>查看 →</span></button>}
      <p className="fine-print">结果仅供娱乐与自我探索，不代表专业心理诊断</p>
    </section>
  )
}

function QuizScreen({ question, current, total, answer, progress, onChoose, onNext, onBack, onExit }: {
  question: Question
  current: number
  total: number
  answer?: number
  progress: number
  onChoose: (index: number) => void
  onNext: () => void
  onBack: () => void
  onExit: () => void
}) {
  return (
    <section className="screen quiz-screen">
      <header className="quiz-header">
        <button className="icon-button" onClick={onExit} aria-label="退出测试">×</button>
        <Brand />
        <span className="question-count">{String(current + 1).padStart(2, '0')} / {String(total).padStart(2, '0')}</span>
      </header>
      <div className="progress-track"><span style={{ width: `${Math.max(progress, 8.3)}%` }} /></div>
      <div className="quiz-intro"><span>第 {current + 1} 题</span><span>凭第一感觉就好</span></div>
      <div className="question-block">
        <p className="scene-label">SCENE {String(current + 1).padStart(2, '0')}</p>
        <h2>{question.scene}<br /><em>{question.prompt}</em></h2>
      </div>
      <div className="options" role="radiogroup" aria-label={question.prompt}>
        {question.options.map((option, index) => (
          <button key={option} className={`option ${answer === index + 1 ? 'selected' : ''}`} onClick={() => onChoose(index)} role="radio" aria-checked={answer === index + 1}>
            <span className="option-index">{String.fromCharCode(65 + index)}</span>
            <span>{option}</span>
            <span className="option-check">{answer === index + 1 ? '✓' : '○'}</span>
          </button>
        ))}
      </div>
      <div className="quiz-footer">
        <button className="back-button" onClick={onBack} disabled={current === 0}>← 上一题</button>
        <button className="next-button" onClick={onNext} disabled={!answer}>{current === total - 1 ? '查看结果' : '下一题'} <span>→</span></button>
      </div>
    </section>
  )
}

function ResultScreen({ age, result, toast, onShare, onAgain, onHome }: { age: number; result: typeof resultCopy[number]; toast: string; onShare: () => void; onAgain: () => void; onHome: () => void }) {
  return (
    <section className="screen result-screen">
      <header className="topbar">
        <Brand />
        <button className="text-button" onClick={onHome}>回到首页</button>
      </header>
      <div className="result-heading"><p className="eyebrow"><span /> 你的心龄档案已生成</p><h1>原来你的心<br /><em>住在这里。</em></h1></div>
      <div className="result-card">
        <div className="result-card-top"><span>MENTAL AGE</span><span>NO. 0001</span></div>
        <div className="age-display"><strong>{age}</strong><span>岁</span></div>
        <div className="result-type">{result.type}</div>
        <p className="result-line">“{result.line}”</p>
        <div className="result-divider" />
        <p className="result-detail">{result.detail}</p>
        <div className="result-tags"><span>好奇心在线</span><span>情绪有弹性</span><span>保留小小天真</span></div>
        <div className="result-stamp">FOR<br />FUN</div>
      </div>
      <div className="result-actions">
        <button className="primary-button" onClick={onShare}>分享我的结果 <span>↗</span></button>
        <button className="secondary-button" onClick={onAgain}>再测一次 <span>↻</span></button>
      </div>
      {toast && <div className="toast" role="status">{toast}</div>}
      <p className="fine-print result-footnote">你的答案没有被上传或保存。想测给朋友，也可以把结果卡截图发给 TA。</p>
    </section>
  )
}

export default App
